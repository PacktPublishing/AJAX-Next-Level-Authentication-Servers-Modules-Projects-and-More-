// importing modules
import { AjaxLib } from "./api/ajax_lib.js";

// grab our page elements
let para = document.getElementsByTagName('p')[0];
let table = document.getElementById('tableResults');
let getButton = document.getElementById('get');
let postButton = document.getElementById('post');
let putButton = document.getElementById('put');
let deleteButton = document.getElementById('delete');

// define our base URL
const SERVER_URL = 'http://127.0.0.1:3000/api';

// ******* GET XHR REQUEST *******

getButton.addEventListener('click', () => {
    fetchDogs();
    // add dynamic text to the paragraph when a GET request is made
    para.className = "get";
    para.textContent = "GET request was successful";
}); 

let fetchDogs = () => {
    let url = SERVER_URL + '/dogs';
    // instantiate our AjaxLib object
    let xhr = new AjaxLib();
    xhr.get(url, (err, dogs) => {
        // if an error is thrown, all other code will stop
        if(err) throw err;
        // we want to return this data and show it on the webpage
        let tableRows = "";
        for (const dog of dogs) {
            tableRows += `
            <tr>
            <td>${dog.id}</td>
            <td>${dog.name}</td>
            <td>${dog.age}</td>
            <td>${dog.gender}</td>
            <td>${dog.notes}</td>
            </tr>
            `;
        };
        table.innerHTML = tableRows;
    })
    
};

// ******* POST XHR REQUEST *******
postButton.addEventListener('click', () => {

    let dog = {
        name: 'Woofey',
        age: 4, 
        gender: 'male',
        notes: 'scruff scruff'
    };

    // send the new dog to our server and add it to our dogs array
    let xhr = new AjaxLib();
    let url = SERVER_URL + "/dogs";
    xhr.post(url, dog, (responseData) => {
        fetchDogs();
        para.className = "post";
        para.textContent = responseData.message;
    })
}); 

// ******* PUT XHR REQUEST *******
putButton.addEventListener('click', () => {
    // we want to update the dog with ID of 1
    let id = 1; 
    let dog = {
        id: id,
        name: 'Skinny the Second',
        age: 2, 
        gender: 'female',
        notes: 'she likes to chase her tail'
    };

    // send the updated dog data to our server and update it in our dogs array
    let xhr = new AjaxLib();
    let url = SERVER_URL + "/dogs/" + id;
    xhr.put(url, dog, (responseData) => {
        fetchDogs();
        para.className = "put";
        para.textContent = responseData.message;
    })
}); 

// ******* DELETE XHR REQUEST *******
deleteButton.addEventListener('click', () => {
    // lets delete dog with id of 1
    let id = 1; 

    // send the updated dog data to our server and update it in our dogs array
    let xhr = new AjaxLib();
    let url = SERVER_URL + "/dogs/" + id;
    xhr.delete(url, (responseData) => {
        fetchDogs();
        para.className = "delete";
        para.textContent = responseData.message;
    })
}); 