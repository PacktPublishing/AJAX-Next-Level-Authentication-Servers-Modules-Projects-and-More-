// grab our page elements
let para = document.getElementsByTagName('p')[0];
let table = document.getElementById('tableResults');
let getButton = document.getElementById('get');
let postButton = document.getElementById('post');
let putButton = document.getElementById('put');
let deleteButton = document.getElementById('delete');

// define our base URL
const SERVER_URL = 'http://127.0.0.1:3000/api';
const DOG_URL = SERVER_URL + "/dogs/";

// ******* GET REQUEST *******

getButton.addEventListener('click', () => {
    // incorporating error handling to only change our paragraph text if there are no errors in our fetchDogs() function
    fetchDogs( (err) => {
        if(err) {
            console.log("oops, your fetchDogs() function did not work!");
        } else {
            // add dynamic text to the paragraph when a GET request is made
            para.className = "get";
            para.textContent = "GET request was successful";
        }
    });
}); 

let fetchDogs = (callback) => {
    // use Axios to perform an AJAX request
    axios
        .get(DOG_URL)
        .then( (res) => {
            let dogs = res.data; 
            let tableRows = "";
            for (const dog of dogs) {
                tableRows += `
                <tr>
                <td>${dog.id}</td>
                <td>${dog.name}</td>
                <td>${dog.age}</td>
                <td>${dog.gender}</td>
                <td>${dog.notes}</td>
                </tr>
                `;
            };
            table.innerHTML = tableRows;
            callback(null);
        })
        .catch(err => callback(err));  
        
}

// ******* POST REQUEST *******
postButton.addEventListener('click', () => {

    let dog = {
        name: 'Woofey',
        age: 4, 
        gender: 'male',
        notes: 'scruff scruff'
    };
    // send the new dog to our server using Axios and add it to our dogs array
    axios
        .post(DOG_URL, dog)
        .then( res => {
            let responseData = res.data; 
            fetchDogs( (err) => {
                console.log('boooooo')
                if(!err) {
                    para.className = "post";
                    para.textContent = responseData.message;
                } else {
                    console.log('There was an error with your POST request. Here is a copy of your error object', err);
                }
            });
        })
        .catch(err => console.log(err));

}); 

// ******* PUT REQUEST *******
putButton.addEventListener('click', () => {
    // we want to update the dog with ID of 1
    let id = 1; 
    let updatedDog = {
        id: id,
        name: 'Skinny the Second',
        age: 2, 
        gender: 'female',
        notes: 'she likes to chase her tail'
    };

    axios
        .put(DOG_URL + id, updatedDog)
        .then( res => {
            let responseData = res.data; 
            fetchDogs( (err) => {
                if(!err) {
                    para.className = "put";
                    para.textContent = responseData.message;
                } else {
                    console.log('There was an error with your PUT request. Here is a copy of your error object', err);
                }
            });
        })
        .catch(err => console.log(err));
}); 

// ******* DELETE REQUEST *******
deleteButton.addEventListener('click', () => {
    // lets delete dog with id of 1
    let id = 1; 
    // send the updated dog data to our server and update it in our dogs array

    axios
        .delete(DOG_URL + id)
        .then((res) => {
            let responseData = res.data;
            fetchDogs( (err) => {
                if(!err) {
                    para.className = "delete";
                    para.textContent = responseData.message;
                } else {
                    console.log('There was an error with your DELETE request. Here is a copy of your error object', err);
                }
            });
        })
}); 