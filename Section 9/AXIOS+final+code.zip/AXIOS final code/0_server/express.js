// grab our modules
// In Node, require() is a built in function to include external modules that exist in seperate files
const express = require('express');
const dogRouter = require('./api/router');
const cors = require('cors');

// initialize our express application
const app = express();

// hostname and port number
const hostname = '127.0.0.1';
const port = 3000;

// set up our server
app.listen(port, hostname, () => {
    console.log(`Express server is started at http://${hostname}:${port}`);
});

// ********* ROUTES *********
// localhost:3000/api => direct to dogRouter
app.use(cors({
    origin: "*"
}));
// use the urlencoded() method if the incoming data is being sent via a form in the format of a url encoded string
// app.use(express.urlencoded());
// use the .json() method if the incoming data is being sent in raw JSON format
app.use(express.json());
app.use('/api', dogRouter);

// ********* SERVER DEFAULT PAGE *********
// localhost:3000/
app.get('/', (req, res) => {
    res.send(`<h1>Our Node.js server is running</h1>`);
});

