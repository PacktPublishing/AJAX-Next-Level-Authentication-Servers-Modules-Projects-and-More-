function AjaxLib() {
    
    // set up our AJAX object / engine
    this.xhr = new XMLHttpRequest();

    // ***** GET XHR REQUEST *****
    this.get = (url, callback) => {
        // configure our AJAX request
        // lets turn this into a SYNCHRONOUS request by passing false as the third argument. Later, in a future section, I'll show you a better way to solve this issue
        this.xhr.open("GET", url, false);
        // define our AJAX callback
        this.xhr.onload = () => {
            if(this.xhr.status === 200) {
                let data = this.xhr.response; 
                let dogs = JSON.parse(data);
                callback(null, dogs);
            } else {
                callback('Error as occured with a GET request');
            }
        }
        // don't forget to send your AJAX request to the server
        this.xhr.send();      

    }

    // ***** POST XHR REQUEST *****
    this.post = (url, dog, callback) => {

        this.xhr.open("POST", url);
        // setting the JSON content header (required in our case because we are sending raw JSON data to the server and not plain text)
        this.xhr.setRequestHeader('Content-Type', 'application/json');
        this.xhr.onload = () => {
            if(this.xhr.status === 200) {
                let data = this.xhr.response; 
                let postResponseData = JSON.parse(data);
                callback(postResponseData);
            } else {
                throw "The status was not 200. Bad."
            }
        }
        this.xhr.onerror = (err) => {
            alert('An error occurred with status: ' + err.currentTarget.status);
        }
        // lets send raw JSON data to the server 
        this.xhr.send(JSON.stringify(dog));
    }

    // ***** PUT XHR REQUEST *****
    this.put = (url, updatedDog, callback) => {

        this.xhr.open("PUT", url);
        // setting the JSON content header (required in our case because we are sending raw JSON data to the server and not plain text)
        this.xhr.setRequestHeader('Content-Type', 'application/json');
        // defining the ajax callback function
        this.xhr.onload = () => {
            if(this.xhr.status === 200) {
                let data = this.xhr.response; 
                let putResponseData = JSON.parse(data);
                callback(putResponseData);
            } else {
                throw "The status was not 200. Bad."
            }
        }
        // as an example, we can also listen for the error event on the XHR Object to catch any other errors that are thrown 
        this.xhr.onerror = (err) => {
            alert('An error occurred with status: ' + err.currentTarget.status);
        }
        // send raw JSON data to the server, by using JSON.stringify()
        this.xhr.send(JSON.stringify(updatedDog));
    };

    // ***** DELETE XHR REQUEST *****
    this.delete = (url, callback) => {

        this.xhr.open("DELETE", url);
        // defining the ajax callback function
        this.xhr.onload = () => {
            if(this.xhr.status === 200) {
                let data = this.xhr.response; 
                let deleteResponseData = JSON.parse(data);
                callback(deleteResponseData);
            } else {
                throw "The status was not 200. Bad."
            }
        }
        this.xhr.onerror = (err) => {
            alert('An error occurred with status: ' + err.currentTarget.status);
        }
        // send the DELETE request to our server
        this.xhr.send();
    }

    









}


export { AjaxLib };