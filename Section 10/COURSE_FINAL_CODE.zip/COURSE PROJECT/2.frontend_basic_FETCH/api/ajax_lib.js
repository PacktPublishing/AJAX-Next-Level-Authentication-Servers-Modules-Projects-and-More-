function AjaxLib() {
    
    // ***** GET REQUEST *****
    this.get = (url, callback) => {
        fetch(url)
            .then(data => data.json())
            .then(responseData => {
                callback(responseData);
            })
            .catch(err => console.log(err))        
    }

    // ***** POST REQUEST *****
    this.post = (url, dog, callback) => {

        // set our headers
        let h = new Headers();
        h.append('Content-Type', 'application/json');
        // set up our request object
        let req = new Request(url, {
            method: "POST", 
            headers: h,
            body: JSON.stringify(dog)   
        });
        // send our ajax request
        fetch(req)
            .then(data => {
                return data.json()}
                )
            .then(responseData => {
                callback(responseData)
            })
            .catch(err => console.log(err));
    }

    // ***** PUT REQUEST *****
    this.put = (url, updatedDog, callback) => {

        // set our headers
        let h = new Headers();
        h.append('Content-Type', 'application/json');
        // set up our request object
        let req = new Request(url, {
            method: "PUT", 
            headers: h,
            body: JSON.stringify(updatedDog)
        });
        // send our ajax request
        fetch(req)
            .then(data => {
                return data.json()}
                )
            .then(responseData => {
                callback(responseData)
            })
            .catch(err => console.log(err));
    }

    // ***** DELETE REQUEST *****
    this.delete = (url, callback) => {

        this.xhr.open("DELETE", url);
        // defining the ajax callback function
        this.xhr.onload = () => {
            if(this.xhr.status === 200) {
                let data = this.xhr.response; 
                let deleteRequestData = JSON.parse(data);
                callback(deleteRequestData);
            } else {
                throw "The status was not 200. Bad."
            }
        }
        this.xhr.onerror = (err) => {
            alert('An error occurred with status: ' + err.currentTarget.status);
        }
        // lets send raw JSON data to the server 
        this.xhr.send();
    }

    // ***** DELETE REQUEST *****
    this.delete = (url, callback) => {
        let req = new Request(url, {
            method: "DELETE"
        })
        fetch(req)
            .then(data => data.json())
            .then(responseData => {
                callback(responseData);
            })
            .catch(err => console.log(err))        
    };
    









}


export { AjaxLib };