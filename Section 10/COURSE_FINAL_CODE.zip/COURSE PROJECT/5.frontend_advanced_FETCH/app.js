// importing modules
import { AjaxLib } from "./api/ajax_lib.js";

// grab our page elements
let table = document.getElementById('tableResults');

// define our base URL
const SERVER_URL = 'http://127.0.0.1:3000/api';

// ******* GET REQUEST *******

window.addEventListener('DOMContentLoaded', () => {
    fetchDogs();
})

let fetchDogs = () => {
    let url = SERVER_URL + '/dogs';
    // instantiate our AjaxLib object
    let fetch = new AjaxLib();
    fetch.get(url, (dogs) => {
        let tableRows = "";
        for (const dog of dogs) {
            tableRows += `
            <tr>
                <td>${dog.id}</td>
                <td>${dog.name}</td>
                <td>${dog.age}</td>
                <td>${dog.gender}</td>
                <td>${dog.notes}</td>
                <td>
                    <button class="delete">Delete Dog</button>
                    <button class="update" onclick="document.getElementById('modalUpdate').style.display='block'">Update</button>
                </td>
            </tr>
            `;
        };
        table.innerHTML = tableRows;    
    })
        
};

// // ******* POST REQUEST *******
let addDogForm = document.getElementById('modal');
addDogForm.addEventListener('submit', (e) => {
    // stop the default behaviour of the page refreshing
    e.preventDefault();
    // create our new dog variable
    let name = document.getElementById('name').value;
    let age = document.getElementById('age').value; 
    let notes = document.getElementById('notes').value;
    let gender = document.getElementById('gender').value;

    let newDog = {name, age, notes, gender};

    // send the new dog to our server and add it to our dogs array
    let fetch = new AjaxLib();
    let url = SERVER_URL + "/dogs";
    fetch
        .post(url, newDog, () => {
            fetchDogs();
            e.target.reset();
            // clearForm();
        });

    // target the modal and close it
    let addDogModal = document.getElementById('modal');
    addDogModal.style.display = 'none';
});

// define our clearForm function
let clearForm = () => {
    document.getElementById('name').value = "";
    document.getElementById('age').value = "";
    document.getElementById('notes').value = "";
    document.getElementById('gender').value = "";
}

// // ******* PUT REQUEST *******

// ***** POPULATE OUR MODAL FORM
let tableWrapper = document.getElementById('tableResults');
tableWrapper.addEventListener('click', (e) => {
    let target = e.target;
    let id = target.parentElement.parentElement.firstElementChild.innerHTML;
    if(target.classList.contains('update')) {
        let fetch = new AjaxLib();
        fetch
            .get(SERVER_URL + "/dogs", (dogs) => {
                let selectedDog = dogs.find((dog) => {
                    return dog.id === id;
                });
                populateUpdateModal(selectedDog);
            })
    };
})

let populateUpdateModal = (relevantDog) => {
    document.getElementById('dogId').value = relevantDog.id;
    document.getElementById('nameUpdate').value = relevantDog.name;
    document.getElementById('ageUpdate').value = relevantDog.age;
    document.getElementById('notesUpdate').value = relevantDog.notes;
    document.getElementById('genderUpdate').value = relevantDog.gender;
};

// ***** SEND A PUT REQUEST TO UPDATE OUR DOG
let updateForm = document.getElementById('updateForm');
updateForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // grab all of our input elements
    let id = document.getElementById('dogId').value;
    let name = document.getElementById('nameUpdate').value;
    let age = document.getElementById('ageUpdate').value;
    let notes = document.getElementById('notesUpdate').value;
    let gender = document.getElementById('genderUpdate').value;

    // create our updated Dog object that we're going to send to the server
    let updatedDog = {name, age, notes, gender};

    // access our fetch module and send a PUT request

    let fetch = new AjaxLib();
    let url = SERVER_URL + "/dogs/" + id;
    fetch
        .put(url, updatedDog, () => {
            fetchDogs();
            e.target.reset();
            let modalUpdate = document.getElementById('modalUpdate');
            modalUpdate.style.display = 'none';
        });
});

// ***** SEND A DELETE REQUEST TO DELETE OUR DOG
tableWrapper.addEventListener('click', (e) => {
    let target = e.target; 
    if(target.classList.contains('delete')) {
        let id = target.parentElement.parentElement.firstElementChild.innerHTML; 
        let fetch = new AjaxLib();
        let url = SERVER_URL + "/dogs/" + id;
        fetch 
            .delete(url, () => {
                // target.parentElement.parentElement.remove();
                fetchDogs();
            })
    }
})