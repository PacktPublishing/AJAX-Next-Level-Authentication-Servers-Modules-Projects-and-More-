// importing modules
import { AjaxLib } from "./api/ajax_lib.js";

// grab our page elements
let para = document.getElementsByTagName('p')[0];
let table = document.getElementById('tableResults');
let getButton = document.getElementById('get');
let postButton = document.getElementById('post');
let putButton = document.getElementById('put');
let deleteButton = document.getElementById('delete');

// define our base URL
const SERVER_URL = 'http://127.0.0.1:3000/api';

// ******* GET REQUEST *******

getButton.addEventListener('click', () => {
    fetchDogs();
    // add dynamic text to the paragraph when a GET request is made
    // in the next section, when defining our Axios library, I will show you how to only execute the next 2 lines if the fetchDogs() function does not return an error
    para.className = "get";
    para.textContent = "GET request was successful";
}); 

let fetchDogs = () => {
    let url = SERVER_URL + '/dogs';
    // instantiate our AjaxLib object
    let fetch = new AjaxLib();
    fetch
        .get(url, (dogs) => {
            let tableRows = "";
            for (const dog of dogs) {
                tableRows += `
                <tr>
                <td>${dog.id}</td>
                <td>${dog.name}</td>
                <td>${dog.age}</td>
                <td>${dog.gender}</td>
                <td>${dog.notes}</td>
                </tr>
                `;
            };
            table.innerHTML = tableRows;    
    });       
}

// ******* POST REQUEST *******
postButton.addEventListener('click', () => {

    let dog = {
        name: 'Woofey',
        age: 4, 
        gender: 'male',
        notes: 'scruff scruff'
    };

    // send the new dog to our server and add it to our dogs array
    let fetch = new AjaxLib();
    let url = SERVER_URL + "/dogs";
    fetch
        .post(url, dog, (responseData) => {
            console.log(responseData)
            fetchDogs();
            para.className = "post";
            para.textContent = responseData.message;
        });
}); 

// ******* PUT REQUEST *******
putButton.addEventListener('click', () => {
    // we want to update the dog with ID of 1
    let id = 1; 
    let updatedDog = {
        id: id,
        name: 'Skinny the Second',
        age: 2, 
        gender: 'female',
        notes: 'she likes to chase her tail'
    };

    // send the updated dog data to our server and update it in our dogs array
    let fetch = new AjaxLib();
    let url = SERVER_URL + "/dogs/" + id;
    fetch
        .put(url, updatedDog, (responseData) => {
            fetchDogs();
            para.className = "put";
            para.textContent = responseData.message;
        });
}); 

// ******* DELETE REQUEST *******
deleteButton.addEventListener('click', () => {
    // lets delete dog with id of 1
    let id = 1; 

    // send the updated dog data to our server and update it in our dogs array
    let fetch = new AjaxLib();
    let url = SERVER_URL + "/dogs/" + id;
    fetch
        .delete(url, (responseData) => {
            fetchDogs();
            para.className = "delete";
            para.textContent = responseData.message;
        });
}); 