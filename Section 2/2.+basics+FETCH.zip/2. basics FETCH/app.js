// ****** TEXT DATA ******
let textButton = document.getElementById('text');
textButton.addEventListener('click', () => {
    // prepare the request
    let url = './data/data.txt';
    fetch(url)
        .then( (data) => {
            if(data.ok) {
                return data.text();
            } else {
                throw new Error('something went wrong');
            }
        })
        .then( (text) => {
            showTextData(text)
        })

    // lets define a display text function
    let showTextData = (text) => {
        let messageTemplate = `<p>${text}</p>`;
        document.getElementById('textCard').innerHTML = messageTemplate;
    }
 
});

// ****** JSON DATA ******

let JSONButton = document.getElementById('json');
JSONButton.addEventListener('click', () => {
    let url = "./data/data.json";
     // prepare the request
    fetch(url)
        .then( (data) => {
            if(data.ok) {return data.json()};
        })
        .then(jsonData => {
            showJSONData(jsonData)
        })

    // display JSON data
    let showJSONData = (dataObject) => {
        let messageTemplate = `<p>${dataObject.book} ${dataObject.verse}</p>`;
        document.getElementById('JSONCard').innerHTML = messageTemplate;
    }

})

// ****** API DATA ******

let APIButton = document.getElementById('api');
APIButton.addEventListener('click', () => {
    // create AJAX object
    let xhr = new XMLHttpRequest();
    let url = "https://bible-api.com/Proverbs+22:1";
    fetch(url)
        .then( (data) => {
            if(data.ok) {return data.json()};
        }) 
        .then(dataObject => {
            showAPIData(dataObject);
        })

    // display API data
    let showAPIData = (dataObject) => {
        let messageTemplate = `<p>${dataObject.reference} ${dataObject.verses[0].text}</p>`;
        document.getElementById('APICard').innerHTML = messageTemplate;
    }

})

