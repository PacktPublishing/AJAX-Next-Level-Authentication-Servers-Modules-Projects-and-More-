// ****** TEXT DATA ******
let textButton = document.getElementById('text');

textButton.addEventListener('click', () => {
    // create an AJAX request
    let xhr = new XMLHttpRequest();
    // prepare the request
    let method = "GET";
    let url = './data/data.txt';

    xhr.open(method, url);

    // send the request
    xhr.send();
    // process the response
    xhr.onload = () => {
        if(xhr.status === 200) {
            console.log(xhr.responseXML);
            let data = xhr.responseText;
            showTextData(data);   
        }
    }

    // lets define a display text function
    let showTextData = (data) => {
        let messageTemplate = `<p>${data}</p>`;
        document.getElementById('textCard').innerHTML = messageTemplate;
    }
 
});

// ****** JSON DATA ******

let JSONButton = document.getElementById('json');
JSONButton.addEventListener('click', () => {
    // create AJAX object
    let xhr = new XMLHttpRequest();
    let method = "GET";
    let url = "./data/data.json";
     // prepare the request
    xhr.open(method, url);

    // send the request
    xhr.send();
    // process the response
    xhr.onload = () => {
        if(xhr.status === 200) {
            console.log(xhr)
            // if you examine the typeof the responseText, you'll see its a string. we want a JavaScript object. We can do this by using the JSON.parse method.
            let dataObject = JSON.parse(xhr.responseText);
            showJSONData(dataObject);
        }
    }

    // display JSON data
    let showJSONData = (dataObject) => {
        let messageTemplate = `<p>${dataObject.book} ${dataObject.verse}</p>`;
        document.getElementById('JSONCard').innerHTML = messageTemplate;
    }

})

// ****** API DATA ******

let APIButton = document.getElementById('api');
APIButton.addEventListener('click', () => {
    // create AJAX object
    let xhr = new XMLHttpRequest();
    let method = "GET";
    let url = "https://bible-api.com/Proverbs+22:1";
     // prepare the request
    xhr.open(method, url);
    // send the request
    xhr.send();
    // process the response
    xhr.onload = () => {
        if(xhr.status === 200) {
            // if you examine the typeof, you'll see its a string. we want an object
            let dataObject = JSON.parse(xhr.responseText);
            showAPIData(dataObject);
        }
    }

    // display API data
    let showAPIData = (dataObject) => {
        console.log(dataObject);
        let messageTemplate = `<p>${dataObject.reference} ${dataObject.verses[0].text}</p>`;
        document.getElementById('APICard').innerHTML = messageTemplate;
    }

})

