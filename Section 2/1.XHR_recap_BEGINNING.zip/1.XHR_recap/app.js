// XHR AJAX REQUEST 

// give it a go. Create your own text file and try and grab the data from it, using the XHR object, and display it to the screen