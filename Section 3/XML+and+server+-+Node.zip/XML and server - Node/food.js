let xhr = new XMLHttpRequest();

function execute(){
    if(xhr.readyState === 0 || xhr.readyState === 4){
        let item = encodeURIComponent(document.getElementById("foodItem").value);
        let url = "http://127.0.0.1:8001/" + item;
        let method = "GET";
        xhr.open(method, url, true );
        xhr.onreadystatechange = handleServerResponse;
        xhr.send();
    }else{
        alert('Oops!');
    }
}

function handleServerResponse(){
    if(xhr.readyState === 4){
        if(xhr.status === 200){
            document.getElementById("output").innerHTML = '<span style = color:blue>' + xhr.responseText + '</span>';
            setTimeout("execute()" , 1000);
        }else{
            alert('Something went wrong');
        }
    }
}