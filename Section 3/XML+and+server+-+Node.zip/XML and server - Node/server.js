/*global require*/
let http = require('http');
let itemArray = ['burger', 'pizza', 'milk', 'bread', 'coke'];

http.createServer( (req, res) => {
    console.log(req);
    let path = req.url;
    console.log(path);
    res.writeHead(200 , { "Content-Type" : "text/plain" , 'Access-Control-Allow-Origin' : '*'});
    
    if(path !== "/") {
        let item = path.slice(1);
        if (itemArray.indexOf(item) !== -1){
         res.end(`Nice. We've got a ${item} in stock`); 
       } else {
         res.end(`We don't have ${item} in stock`);
       }
    } else{
        res.end("Please type something!");
    }
}).listen(8001);